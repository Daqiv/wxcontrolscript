
Constants = {}

Constants.upperleft_x = 50;  --左上角X或者返回箭头X坐标
Constants.upperleft_y = 100; --左上角X或者返回箭头Y坐标
Constants.bottomleft_x = 70;  --左下角X或者返回箭头X坐标
Constants.bottomleft_y = 1240; --左下角X或者返回箭头Y坐标


Constants.upperright_x = 650; --右上角[完成]X坐标
Constants.upperright_y = 100; --右上角[完成]Y坐标
Constants.bottomright_x = 650; --右下角X坐标
Constants.bottomright_y = 1230; --右下角Y坐标



--Constants.relogin_pwd_x = 150; --重登录密码框X坐标
--Constants.relogin_pwd_y = 646; --重登录密码框Y坐标
--Constants.relogin_lgbtn_x = 400; --重登录按钮X坐标
--Constants.relogin_lgbtn_y = 800; --重登录按钮Y坐标
Constants.relogin_pwd_x = 150; --重登录密码框X坐标
Constants.relogin_pwd_y = 730; --重登录密码框Y坐标
Constants.relogin_lgbtn_x = 400; --重登录按钮X坐标
Constants.relogin_lgbtn_y = 700; --重登录按钮Y坐标



Constants.moments_friend_x = 188; --发现页面朋友圈图标X坐标
Constants.moments_friend_y = 236; --发现页面朋友圈图标Y坐标
Constants.moments_ul_xj_x = 666;  --朋友圈左上角相机图标X坐标
Constants.moments_ul_xj_y = 100;  --朋友圈左上角相机图标Y坐标
Constants.moments_xj_zp_x = 128; --点击朋友圈左上角相机后显示的照片图标X坐标
Constants.moments_xj_zp_y = 720; --点击朋友圈左上角相机后显示的照片图标Y坐标
Constants.moments_xj_zp_zdy_x = 220; --点击[图片和视频]后显示的自定义文件夹的X坐标
Constants.moments_xj_zp_zdy_y = 890; --点击[图片和视频]后显示的自定义文件夹的Y坐标
				--200,170 440,170 680,170
				--200,420 440,420 680,420
				--200,660 440,660 680,660
Constants.moments_xj_zp_1_1_x = 200; --第1行第1张照片右上角对勾X坐标
Constants.moments_xj_zp_1_1_y = 170; --第1行第1张照片右上角对勾Y坐标
Constants.moments_xj_zp_1_2_x = 440; --第1行第2张照片右上角对勾X坐标
Constants.moments_xj_zp_1_2_y = 170; --第1行第2张照片右上角对勾Y坐标
Constants.moments_xj_zp_1_3_x = 680; --第1行第3张照片右上角对勾X坐标
Constants.moments_xj_zp_1_3_y = 170; --第1行第3张照片右上角对勾Y坐标

Constants.moments_xj_zp_2_1_x = 200; --第2行第1张照片右上角对勾X坐标
Constants.moments_xj_zp_2_1_y = 420; --第2行第1张照片右上角对勾Y坐标
Constants.moments_xj_zp_2_2_x = 440; --第2行第2张照片右上角对勾X坐标
Constants.moments_xj_zp_2_2_y = 420; --第2行第2张照片右上角对勾Y坐标
Constants.moments_xj_zp_2_3_x = 680; --第2行第3张照片右上角对勾X坐标
Constants.moments_xj_zp_2_3_y = 420; --第2行第3张照片右上角对勾Y坐标

Constants.moments_xj_zp_3_1_x = 200; --第2行第1张照片右上角对勾X坐标
Constants.moments_xj_zp_3_1_y = 660; --第2行第1张照片右上角对勾Y坐标
Constants.moments_xj_zp_3_2_x = 440; --第2行第2张照片右上角对勾X坐标
Constants.moments_xj_zp_3_2_y = 660; --第2行第2张照片右上角对勾Y坐标
Constants.moments_xj_zp_3_3_x = 680; --第2行第3张照片右上角对勾X坐标
Constants.moments_xj_zp_3_3_y = 660; --第2行第3张照片右上角对勾Y坐标


Constants.moments_xj_zp_complete_x = 620; --选择照片界面右上角完成按钮X坐标
Constants.moments_xj_zp_complete_y = 100; --选择照片界面右上角完成按钮Y坐标


Constants.moments_xj_xsp_x = 146; --点击朋友圈左上角相机后显示的小视频图标X坐标
Constants.moments_xj_xsp_y = 712; --点击朋友圈左上角相机后显示的小视频图标Y坐标


Constants.my_sz_x = 150;  --[我页面]-[设置]按钮X坐标
Constants.my_sz_y = 1030; --[我页面]-[设置]按钮Y坐标
Constants.my_sz_ty_x = 100; --[我页面]-[设置]-[通用]按钮X坐标
Constants.my_sz_ty_y = 620; --[我页面]-[设置]-[通用]按钮Y坐标
Constants.my_sz_ty_gn_x = 100; --[我页面]-[设置]-[通用]-[功能]按钮X坐标
Constants.my_sz_ty_gn_y = 710; --[我页面]-[设置]-[通用]-[功能]按钮Y坐标
Constants.my_sz_ty_gn_txxw_x = 100; --[我页面]-[设置]-[通用]-[功能]-[腾讯新闻]按钮X坐标
Constants.my_sz_ty_gn_txxw_y = 566; --[我页面]-[设置]-[通用]-[功能]-[腾讯新闻]按钮Y坐标
Constants.my_sz_ty_gn_txxw_txxw_x = 100; --[我页面]-[设置]-[通用]-[功能]-[腾讯新闻]-[腾讯新闻]按钮X坐标
Constants.my_sz_ty_gn_txxw_txxw_y = 520; --[我页面]-[设置]-[通用]-[功能]-[腾讯新闻]-[腾讯新闻]按钮Y坐标

Constants.tongxunlu_newfriend_x = 60; --[通讯录]-[新的朋友]按钮X坐标
Constants.tongxunlu_newfriend_y = 200; --[通讯录]-[新的朋友]按钮Y坐标
Constants.tongxunlu_newfriend_mc_x = 60 --[通讯录]-[新的朋友]-[手机联系人]按钮X坐标
Constants.tongxunlu_newfriend_mc_y = 850 --[通讯录]-[新的朋友]-[手机联系人]按钮Y坐标
Constants.tongxunlu_newfriend_mc_m_x = 60 --[通讯录]-[新的朋友]-[手机联系人]-[添加手机联系人]按钮X坐标
Constants.tongxunlu_newfriend_mc_m_y = 230 --[通讯录]-[新的朋友]-[手机联系人]-[添加手机联系人]按钮Y坐标

